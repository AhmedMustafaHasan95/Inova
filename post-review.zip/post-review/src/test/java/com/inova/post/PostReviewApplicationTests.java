package com.inova.post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
