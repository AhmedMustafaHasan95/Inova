package com.inova.post.service.users;

import com.inova.post.DTO.UserDTO;

public interface UserService {
    public UserDTO createUser(UserDTO userDTO);
}
